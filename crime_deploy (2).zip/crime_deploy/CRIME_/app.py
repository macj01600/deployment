from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model
area_map = {
    '03': 'Southwest',
    '01': 'Central',
    '15': 'N Hollywood',
    '19': 'Mission',
    '17': 'Devonshire',
    '11': 'Northeast',
    '05': 'Harbor',
    '09': 'Van Nuys',
    '10': 'West Valley',
    '08': 'West LA',
    '07': 'Wilshire',
    '02': 'Rampart',
    '12': '77th Street',
    '04': 'Hollenbeck',
    '18': 'Southeast',
    '14': 'Pacific',
    '13': 'Newton',
    '06': 'Hollywood',
    '16': 'Foothill',
    '20': 'Olympic',
    '21': 'Topanga'
}
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

    # Define feature names
    feature_names = ['Vict_Age', 'Vict_Descent', 'Crm_Cd', 'Premis_Cd', 'dayofweek', 'month', 'Vict_Sex_F',
                     'Vict_Sex_M', 'Vict_Sex_X']

    # Set feature names for the model
    model.feature_names = feature_names
# Define route for home page
@app.route('/')
def home():
    return render_template('index.html')

# Define route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from form

    vict_descent_num = int(request.form['Vict_Descent'])
    input_data = [request.form['Vict_Age'], vict_descent_num, request.form['Crm_Cd'],
                  request.form['Premis_Cd'],
                  #request.form['Status'],
                  request.form['dayofweek'],
                  #request.form['day'],
                  request.form['month']]
                  # request.form['Vict_Sex_F'],
                  # request.form['Vict_Sex_M'], request.form['Vict_Sex_X']]

    gender = request.form['Gender']

    # Set values for gender columns based on gender selection
    if gender == 'M':
        input_data.extend([1, 0, 0])  # Male selected
    elif gender == 'F':
        input_data.extend([0, 1, 0])  # Female selected
    else:
        input_data.extend([0, 0, 1])  # Other selected

    # Convert input data to array and reshape
    input_array = np.array(input_data).reshape(1, -1)

    # Make prediction
    prediction = model.predict(input_array)


    prediction_str = str(prediction[0])
    prediction_name = area_map.get(prediction_str)
    # Pass prediction back to the user
    return render_template('result.html', prediction=prediction_name)




if __name__ == '__main__':
    app.run(debug=True)
