import numpy as np
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
from pylab import rcParams
import pickle
# Set figure size for plots
rcParams['figure.figsize'] = 12, 6

# Now you can proceed with writing the rest of your code using the imported libraries

pd.options.mode.chained_assignment = None  # Suppress SettingWithCopyWarning

crime = pd.read_csv("crime_78__.csv")
print(crime)

# Drop two columns
columns_to_drop = ['Status', 'day']
crime.drop(columns=columns_to_drop, inplace=True)

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

X = crime.drop('AREA',axis = 1)
y = crime['AREA']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20)


# Model selection and training
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

from sklearn.metrics import precision_score, recall_score, accuracy_score, f1_score
# Make predictions on the test set
y_pred = rf.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred,average='weighted')
recall = recall_score(y_test, y_pred,average='weighted')
f1 = f1_score(y_test, y_pred,average='weighted')
print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1)

import pickle
from sklearn.ensemble import RandomForestClassifier

# Assuming 'rf' is your trained RandomForestClassifier model
# Saving the model
with open('model.pkl', 'wb') as f:
    pickle.dump(rf, f)

# Loading the model
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)
print(crime['AREA'].unique())
